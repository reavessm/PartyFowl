export interface User {
    email: string;
    password: string;
    fullName: string;
    username: string;
    dob: string;
}
