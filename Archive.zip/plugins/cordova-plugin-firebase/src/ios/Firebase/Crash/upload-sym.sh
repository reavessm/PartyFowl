#!/bin/bash

echo "$0:0: error: $0 has been removed.  Please use upload-sym instead."
exit 1
